create function findallappointmentsbydate(apptdate date)
    returns TABLE("scheduledAt" timestamp without time zone, "aptId" bigint, "tId" bigint, "cId" bigint, "firstName" character varying, "lastName" character varying, "pId" bigint, "therapistId" bigint, "therapistName" character varying, "therapistType" character varying, "bodyRegionDisplayName" character varying)
    language sql
as
$$
SELECT
    a.scheduled_at,
    a.apt_id,
    a.t_id,
    a.c_id,
    p.first_name,
    p.last_name,
    p.p_id,
    t.t_id,
    t.therapist_name,
    t.therapist_type,
    br.display_name
FROM appointments AS a
    JOIN therapists AS t ON t.t_id = a.t_id
    JOIN cases AS c ON c.c_id = a.c_id
    JOIN patients AS p ON p.p_id = c.p_id
    JOIN body_regions AS br ON br.br_id = c.br_id
WHERE a.scheduled_at >= apptDate
AND a.scheduled_at < apptDate + INTERVAL '1 day'
ORDER BY a.scheduled_at;
$$;

alter function findallappointmentsbydate(date) owner to clinicflow_user;

